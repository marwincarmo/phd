# Load necessary libraries for graph manipulation and plotting
library(ggplot2)
library(tidyr)
library(dplyr)
library(igraph)

cascade.Watts = function(g, thrsh.lim = c(0.05, 0.90), max.steps = 10000){
  # g: An igraph graph object (the network)
  # thrsh.lim: A vector c(min_threshold, max_threshold) for the uniform distribution
  # max.steps: Maximum number of simulation steps to prevent infinite loops
  
  Cascades = list() # To store results for different seed nodes
  metrics = igraph::degree(g) # Calculate the degree (number of neighbors) for each node
  
  # --- 1. Identify Seed Nodes ---
  # The simulation will be run starting a cascade from three types of nodes:
  # max_node: The node with the highest degree
  # min_node: The node with the lowest non-zero degree (to avoid isolated nodes with 0 degree if possible)
  # avg_node: A node whose degree is closest to the average degree of the network
  max_node = which.max(metrics)
  # if a node degree is zero, we tell R to not pick that one, ignore it and pick the next one
  # if a node is not connected to anything, than it cannot produce a failure
  # transform the nodes with zero degree in 999 and pick the minimum from that
  if(min(metrics, na.rm = TRUE) == 0){ # Handle cases where min degree is 0
    min_node = which.min(ifelse(metrics != 0 & !is.na(metrics), metrics, 999)) # Find min non-zero
  } else {
    min_node = which.min(ifelse(!is.na(metrics), metrics, 999))
  }
  # the average will almost never be a whole number, so this function finds the
  # node that has the closest degree to the average
  avg_node = sample(which(abs(metrics - floor(mean(metrics, na.rm = TRUE))) == 
                            min(abs(metrics - floor(mean(metrics, na.rm = TRUE))), na.rm = TRUE) & 
                            !is.na(metrics)), 1) # Sample one node close to average degree
  
  seeds = list(high = max_node, 
               avg = avg_node,
               low = min_node)
  
  # --- 2. Loop Through Each Seed Node ---
  for(name in names(seeds)) { # For "high", "avg", "low"
    target = seeds[[name]] # Get the actual node ID for the current seed type
    
    # Ensure threshold limits are in correct order (lower, upper)
    if(thrsh.lim[1] > thrsh.lim[2]){
      message("First limit should be the lower limit! Flipping for you")
      thrsh.lim = c(thrsh.lim[2], thrsh.lim[1])
    }
    
    # --- 3. Initialize Network for this Cascade Run ---
    # Assign a random threshold to each node, drawn from a uniform distribution
    # with minimum and maximum as the threshold limits
    # V(g) accesses vertex attributes of the graph 'g'
    V(g)$threshold = runif(vcount(g), min = thrsh.lim[1], max = thrsh.lim[2])
    # Set all nodes to initial state 0 (not failed)
    V(g)$state = 0
    # Set the target seed node to state 1 (failed)
    V(g)$state[target] = 1
    
    # Track the number of failed nodes at each step
    flip.count = c(sum(V(g)$state)) # Initial count (just the seed node)
    step = 0
    
    # --- 4. Simulate the Cascade ---
    while(step < max.steps) {
      step = step + 1
      new.state = V(g)$state # Store current state to check for changes later
      
      # Iterate through each vertex 'v' in the graph
      for (v_id in V(g)) { # v_id is the numerical ID of the vertex
        if (V(g)$state[v_id] == 1) next # If node is already failed, skip it
        
        neighbors.v = neighbors(g, v_id) # Get the neighbors of node 'v_id'
        
        if (length(neighbors.v) == 0) next # If node has no neighbors, it can't fail due to them
        
        # Calculate the fraction of its neighbors that are currently failed
        active_fraction = sum(V(g)$state[neighbors.v]) / length(neighbors.v)
        
        # Check if this fraction meets or exceeds the node's threshold
        if (active_fraction >= V(g)$threshold[v_id]) {
          new.state[v_id] = 1 # If so, this node fails in the next state
        }
      }
      
      # Check if any nodes changed state in this step
      if(all(new.state == V(g)$state)) break # If no states changed, the cascade has stopped
      
      V(g)$state = new.state # Update the graph's state
      flip.count = c(flip.count, sum(V(g)$state)) # Record the new total number of failed nodes
    }
    # Store the proportion of failed nodes over time for this seed type
    Cascades[[name]] = flip.count / vcount(g)
  }
  names(Cascades) = c("High", "Average", "Low") # Rename for clarity in output
  return(Cascades) # Return the list of cascade dynamics
}

# [21:59.280 --> 22:04.960]  that micah and i are working on in terms of you can also identify like the distribution of your graph and what
# [22:04.960 --> 22:12.240]  that means right so this would at least indicate that the structure of the graph gives rise to this
# [22:12.240 --> 22:18.880]  concept of resilience right so certain nodes or certain graphs are more resilient to failure than
# [22:18.880 --> 22:25.440]  others one way of thinking about that is how much homogeneity do you see in the graph right so if the graph
# [22:25.440 --> 22:30.880]  always results in failure no matter what you pick then clearly it's not a resilient graph because anything
# [22:30.880 --> 22:36.160]  you if you knock anything down everything will fall down with it whereas say with the barabashi albert model
# [22:36.960 --> 22:42.960]  it's generally resilient up to the point that you knock out the hub if you knock out the hub everything seems to fail

cascade.Xiang = function(g, beta = 1, T = 1.2, alpha = 1, max.steps = 10000) {
  # g: igraph graph object
  # beta: Scaling factor for initial load
  # T: Tolerance parameter (Capacity = T * Initial_Load)
  # alpha: Exponent for degree in load calculation and redistribution (L_i = beta * k_i^alpha)
  # max.steps: Max simulation steps
  
  N = vcount(g) # Number of nodes
  deg = igraph::degree(g) # Degree of each node
  
  # --- 1. Initialize Load and Capacity ---
  # Initial load depends on degree, beta, and alpha
  load0 = beta * (deg^alpha)
  # Capacity is initial load times tolerance T
  cap = T * load0
  
  # --- 2. Identify Seed Nodes (similar to Watts version) ---
  high = which.max(deg)
  low = which.min(deg)
  # A simpler way to pick an average-ish node if exact mean degree node not present
  avg = which.min(abs(deg - mean(deg)))[1] # Takes the first if multiple are equally close
  seeds = list(High=high, Average=avg, Low=low)
  
  # --- 3. Loop Through Each Seed Node using lapply ---
  # lapply will iterate through 'seeds', apply the inner function, and return a list
  results = lapply(seeds, function(seed_node_id) {
    # --- Initialize for this cascade run ---
    load = load0 # Reset load to initial load for each run
    failed = logical(N) # Vector to track failed nodes (all FALSE initially)
    
    # --- 4. Initiate Failure at Seed Node ---
    failed[seed_node_id] = TRUE # Mark the seed node as failed
    nbrs = as.integer(neighbors(g, seed_node_id)) # Get neighbors of the seed node
    
    # Redistribute seed node's load
    if (length(nbrs) > 0) { # If it has neighbors
      # Weights for redistribution are based on neighbors' degrees (or deg^alpha)
      active_nbrs = nbrs[!failed[nbrs]] # Only consider neighbors that are NOT already failed
      if(length(active_nbrs) > 0){
        wts = deg[active_nbrs]^alpha
        # Add the seed's load to its active neighbors, proportionally to wts
        load[active_nbrs] = load[active_nbrs] + load0[seed_node_id]*(wts/sum(wts))
      }
    }
    load[seed_node_id] = 0 # Failed node has no load
    
    # Track proportion of failed nodes
    series = sum(failed)/N # Proportion failed at step 1
    t = 1 # Step counter
    
    # --- 5. Simulate the Cascade ---
    while (t < max.steps) {
      # Identify nodes that will fail in this step:
      # They are not already failed AND their current load exceeds their capacity
      to_fail_in_this_step = which(!failed & (load > cap))
      
      if (!length(to_fail_in_this_step)) break # If no nodes are failing, cascade stops
      
      # Process newly failed nodes
      for (v_id in to_fail_in_this_step) {
        failed[v_id] = TRUE # Mark as failed
        # Get its neighbors that are STILL ACTIVE (not in 'failed' and not in 'to_fail_in_this_step' yet from *this round*)
        # Important: only redistribute to nodes that are not already marked as failed *before* this loop started
        # And ensure neighbors are not among those failing in the *current* step already,
        # to avoid double-counting or instantaneous re-distribution to a node that just failed.
        # A simple way is to get all neighbors and then filter out any that are in the overall 'failed' set.
        
        current_v_load = load[v_id] # Store load before zeroing, for redistribution
        load[v_id] = 0 # Failed node's load goes to 0
        
        nbrs2 = as.integer(neighbors(g, v_id))
        active_nbrs2 = nbrs2[!failed[nbrs2]] # Neighbors that are not YET failed
        
        if (length(active_nbrs2) > 0) {
          w2 = deg[active_nbrs2]^alpha # Weights for redistribution
          # Add v_id's load to its active neighbors
          load[active_nbrs2] = load[active_nbrs2] + current_v_load*(w2/sum(w2))
        }
      }
      t = t+1
      series[t] = sum(failed)/N # Record proportion failed
    }
    series # Return the time series of proportion failed for this seed
  })
  
  names(results) = names(seeds) # Name the elements of the list
  results
}